﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Bom : Stats
    {
        int jangkauan;
        public Bom(int x, int y, int w, int h, string image, int jangkauan) : base(x, y, w, h, image)
        {
            this.jangkauan = jangkauan;
        }

        public int Jangkauan { get => jangkauan; set => jangkauan = value; }
    }
}
