﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Player : Stats
    {
        int gx = 25, gy = 25;
        public Player(int x, int y, int w, int h, string image) : base(x, y, w, h, image)
        {
        }

        public int Gx { get => gx; set => gx = value; }
        public int Gy { get => gy; set => gy = value; }
    }
}
