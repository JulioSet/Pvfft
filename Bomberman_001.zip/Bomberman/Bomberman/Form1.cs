﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bomberman
{
    public partial class Form1 : Form
    {
        string projectDirectory;
        string workingDirectory = Environment.CurrentDirectory;
        string path_font;

        PrivateFontCollection pfc = new PrivateFontCollection();

        public Form1()
        {
            InitializeComponent();
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            path_font = projectDirectory + "//Resource//Pixeboy-z8XGD.ttf";
            pfc.AddFontFile(path_font);
            label1.Font = new Font(pfc.Families[0], 26, FontStyle.Regular);
            label2.Font = new Font(pfc.Families[0], 26, FontStyle.Regular);
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2(this);
            f.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label1_MouseEnter(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = false;
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
        }

        private void label2_MouseEnter(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = true;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
        }
    }
}
