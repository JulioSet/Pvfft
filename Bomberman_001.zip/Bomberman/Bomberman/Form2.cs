﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bomberman
{
    public partial class Form2 : Form
    {
        string projectDirectory;
        string workingDirectory = Environment.CurrentDirectory;
        string path_font;

        Form1 balik;
        PrivateFontCollection pfc = new PrivateFontCollection();

        public Form2(Form1 a)
        {
            InitializeComponent();
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            path_font = projectDirectory + "//Resource//Pixeboy-z8XGD.ttf";
            pfc.AddFontFile(path_font);
            balik = a;
            //textBox1.Font = new Font(pfc.Families[0], 18, FontStyle.Regular);
        }

        // game settings
        Player pl = new Player(25, 25, 25, 25, "a");
        List<Wall> softWall = new List<Wall>();

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            balik.Dispose();
        }
    }
}
