﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Wall : Stats
    {
        double id;
        public Wall(int x, int y, int w, int h, string image, double id) : base(x, y, w, h, image)
        {
            this.id = id;
        }

        public double Id { get => id; set => id = value; }
    }
}
