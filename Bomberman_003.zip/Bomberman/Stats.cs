﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Stats
    {
        int x, y, w, h;
        string image;

        public Stats(int x, int y, int w, int h, string image)
        {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.image = image;
        }

        public int X { get => x; set => x = value; }
        public int Y { get => y; set => y = value; }
        public int W { get => w; set => w = value; }
        public int H { get => h; set => h = value; }
        public string Image { get => image; set => image = value; }
    }
}
