﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Enemy : Stats
    {
        int gx, gy;

        public Enemy(int x, int y, int w, int h, string image, int gx, int gy) : base(x, y, w, h, image)
        {
            this.gx = gx;
            this.gy = gy;
        }

        public int Gx { get => gx; set => gx = value; }
        public int Gy { get => gy; set => gy = value; }
    }
}
