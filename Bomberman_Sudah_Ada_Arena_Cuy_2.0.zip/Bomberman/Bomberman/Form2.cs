﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;


namespace Bomberman
{
    public partial class Form2 : Form
    {
        string projectDirectory;
        string workingDirectory = Environment.CurrentDirectory;
        string path_font;
        
        Graphics g;
        Form1 balik;
        PrivateFontCollection pfc = new PrivateFontCollection();
        Random Rnd = new Random();

        public Form2(Form1 a)
        {
            InitializeComponent();
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            path_font = projectDirectory + "//Resource//Pixeboy-z8XGD.ttf";
            
            pfc.AddFontFile(path_font);
            balik = a;
            //textBox1.Font = new Font(pfc.Families[0], 18, FontStyle.Regular);
        }

        // game settings
        Player pl = new Player(25, 25, 25, 25, "a");
        List<Wall> softWall = new List<Wall>();
        List<Wall> hardWall = new List<Wall>();

        void GenerateHardwall()
        {
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_wall = projectDirectory + "//Resource//Tembokkeras.jpg";
            for (int i = 0; i <= 16; i++)
            {
                for (int j = 0; j <= 16; j++)
                {
                    string Id = i + "." + j;
                    if (i == 0 || j == 0 || i == 16 || j == 16)
                    {
                        hardWall.Add(new Wall(25 * j, 25 * i, 25, 25, path_wall, double.Parse(Id)));
                    }
                    else if (i % 2 == 0 && j % 2 == 0)
                    {
                        hardWall.Add(new Wall(25 * j, 25 * i, 25, 25, path_wall, double.Parse(Id)));
                    }

                }
            }
        }

        void Generatesofwall()
        {

            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_wall = projectDirectory + "//Resource//TembokHalus.jpg";
            int rnmx = 0;
            int rnmy = 0;
            bool cek = false;
            
            for (int i = 0; i <= 50; i++)
            {
                rnmx = Rnd.Next(1, 16);
                rnmy = Rnd.Next(1, 16);
                if (rnmx % 2 == 0 && rnmy % 2 == 0 )
                {
                    bool salah = true;
                    while (salah == true)
                    {
                        rnmx = Rnd.Next(1, 16);
                        rnmy = Rnd.Next(1, 16);
                        if (rnmx % 2 == 0 && rnmy % 2 == 0)
                        {
                            rnmx = Rnd.Next(1, 16);
                            rnmy = Rnd.Next(1, 16);
                        }
                        else
                        {
                            cek = true;
                            salah = false;
                        }
                    }
                    
                }
                else
                {
                    cek = true;
                }

                if (cek=true)
                {
                    string Id = rnmx + "." + rnmy;
                    Console.WriteLine(rnmy + "," + rnmx);
                    softWall.Add(new Wall(25 * rnmx, 25 * rnmy, 25, 25, path_wall, double.Parse(Id)));
                }
                   
                
            }
        }



        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            balik.Dispose();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            g = e.Graphics;

            foreach (var item in hardWall)
            {
                Image IMG = Image.FromFile(item.Image);
                g.DrawImage(IMG, item.X, item.Y, item.W, item.H);

            }
            foreach (var item in softWall)
            {
                Image IMG = Image.FromFile(item.Image);
                g.DrawImage(IMG, item.X, item.Y, item.W, item.H);

            }


        }

        private void Form2_Load(object sender, EventArgs e)
        {
            GenerateHardwall();
            Generatesofwall();
        }
    }
}
