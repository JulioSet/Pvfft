﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Printing;


namespace Bomberman
{
    public partial class Form2 : Form
    {
        string projectDirectory;
        string workingDirectory = Environment.CurrentDirectory;
        string path_font;
        
        Graphics g;
        Form1 balik;
        PrivateFontCollection pfc = new PrivateFontCollection();
        Random Rnd = new Random();

        public Form2(Form1 a)
        {
            InitializeComponent();
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            path_font = projectDirectory + "//Resource//Pixeboy-z8XGD.ttf";
            
            pfc.AddFontFile(path_font);
            balik = a;
            //textBox1.Font = new Font(pfc.Families[0], 18, FontStyle.Regular);
        }

        // game settings
        //List<Wall> softWall = new List<Wall>();
        //List<Wall> hardWall = new List<Wall>();

        // player settings
        Player pl; string path_player;
        int xPlayer = 0; int yPlayer = 0; int player = 0;
        int hardWallAtas = 0; int hardWallBawah = 16;
        int detik_bom = 0; int bom = 0; int bomX = 0; int bomY = 0;
        int ledakan = 0; int detik_ledakan = 0;

        bool check_random(int x, int y)
        {
            foreach (Control item in panel1.Controls)
            {
                if (item is PictureBox)
                {
                    if (player == 0 && x * 35 == item.Location.X && y * 35 == item.Location.Y)
                    {
                        return true;
                    }
                    else
                    {
                        if (x * 35 == item.Location.X && y * 35 == item.Location.Y)
                        {
                            return true;
                        }
                        if (xPlayer + 1 == x && yPlayer + 1 == y || xPlayer + 1 == x && yPlayer - 1 == y || xPlayer - 1 == x && yPlayer + 1 == y || xPlayer - 1 == x && yPlayer - 1 == y)
                        {
                            return true;
                        }
                        //if (xPlayer + 1 == x && yPlayer - 1 == y)
                        //{
                        //    return true;
                        //}
                        //if (xPlayer - 1 == x && yPlayer + 1 == y)
                        //{
                        //    return true;
                        //}
                        //if (xPlayer - 1 == x && yPlayer - 1 == y)
                        //{
                        //    return true;
                        //}
                    }
                }
            }
            return false;
        }

        void GeneratePlayer(){
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            path_player = projectDirectory + "//Resource//Player//jalanDepanIdle.png";
            while (check_random(xPlayer, yPlayer))
            {
                xPlayer = Rnd.Next(1, 16);
                yPlayer = Rnd.Next(1, 16);
            }
            PictureBox picture = new PictureBox
            {
                Name = "Player",
                Size = new Size(35, 35),
                Location = new Point(xPlayer * 35, yPlayer * 35)
            };
            picture.ImageLocation = path_player;
            picture.SizeMode = PictureBoxSizeMode.StretchImage;
            panel1.Controls.Add(picture);
            player++;
            //foreach (Wall w in softWall)
            //{
            //    while (w.X == xPlayer && w.Y == yPlayer)
            //    {
            //        xPlayer = Rnd.Next(1, 15);
            //        yPlayer = Rnd.Next(1, 15);
            //    }
            //}
            //foreach (Wall w in hardWall)
            //{
            //    while (w.X == xPlayer && w.Y == yPlayer)
            //    {
            //        xPlayer = Rnd.Next(1, 16);
            //        yPlayer = Rnd.Next(1, 16);
            //    }
            //}

            //MessageBox.Show(string.Format("{0} - {1}", xPlayer, yPlayer));
            //pl = new Player(xPlayer, yPlayer, 35, 35, path_player);
        }

        void GenerateEnemy()
        {
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_enemy = projectDirectory + "//Resource//pontansp6.gif";
            int rJum = 0; // random jumlah musuh
            int rArah = 0; // random arah musuh (0 = atas bawah, 1 = kanan kiri)
            int rnmx = 0; // random tempat spawn
            int rnmy = 0; // random tempat spawn

            rJum = Rnd.Next(3, 5);

            for (int j = 0; j < rJum; j++)
            {
                //rArah = Rnd.Next(0, 1);
                while (check_random(rnmx, rnmy))
                {
                    rnmx = Rnd.Next(1, 16);
                    rnmy = Rnd.Next(1, 16);
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Enemy",
                    Size = new Size(35, 35),
                    Location = new Point(rnmx * 35, rnmy * 35),
                    Tag = j
                };
                picture.ImageLocation = path_enemy;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }
        }

        void GenerateHardwall()
        {
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_wall = projectDirectory + "//Resource//Tembokkeras.jpg";
            for (int i = 0; i <= 16; i++)
            {
                for (int j = 0; j <= 16; j++)
                {
                    //string Id = i + "." + j;
                    if (i == hardWallAtas || j == hardWallAtas || i == hardWallBawah || j == hardWallBawah)
                    {
                        //hardWall.Add(new Wall(j, i, 35, 35, path_wall, double.Parse(Id)));
                        PictureBox picture = new PictureBox
                        {
                            Size = new Size(35, 35),
                            Location = new Point(j * 35, i * 35)
                        };
                        picture.ImageLocation = path_wall;
                        picture.SizeMode = PictureBoxSizeMode.StretchImage;
                        panel1.Controls.Add(picture);
                    }
                    else if (i % 2 == 0 && j % 2 == 0)
                    {
                        //hardWall.Add(new Wall(j, i, 35, 35, path_wall, double.Parse(Id)));
                        PictureBox picture = new PictureBox
                        {
                            Size = new Size(35, 35),
                            Location = new Point(j * 35, i * 35)
                        };
                        picture.ImageLocation = path_wall;
                        picture.SizeMode = PictureBoxSizeMode.StretchImage;
                        panel1.Controls.Add(picture);
                    }
                }
            }
        }

        void Generatesofwall()
        {
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_wall = projectDirectory + "//Resource//TembokHalus.jpg";
            int rnmx = 0;
            int rnmy = 0;
            //bool cek = false;
            
            for (int i = 0; i < 50; i++)
            {
                rnmx = 0;
                rnmy = 0;
                while (check_random(rnmx, rnmy))
                {
                    rnmx = Rnd.Next(1, 16);
                    rnmy = Rnd.Next(1, 16);
                }
                PictureBox picture = new PictureBox
                {
                    Name = "softwall",
                    Size = new Size(35, 35),
                    Location = new Point(rnmx * 35, rnmy * 35),
                    Tag = i
                };
                picture.ImageLocation = path_wall;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
                //if (rnmx % 2 == 0 && rnmy % 2 == 0 )
                //{
                //    bool salah = true;
                //    while (salah == true)
                //    {
                //        rnmx = Rnd.Next(1, 16);
                //        rnmy = Rnd.Next(1, 16);
                //        if (rnmx % 2 == 0 && rnmy % 2 == 0)
                //        {
                //            rnmx = Rnd.Next(1, 16);
                //            rnmy = Rnd.Next(1, 16);
                //        }
                //        else
                //        {
                //            cek = true;
                //            salah = false;
                //        }
                //    }

                //}
                //else
                //{
                //    cek = true;
                //}

                //if (cek)
                //{
                //    string Id = rnmx + "." + rnmy;
                //    Console.WriteLine(rnmy + "," + rnmx);
                //    softWall.Add(new Wall(rnmx, rnmy, 35, 35, path_wall, double.Parse(Id)));
                //}

            }
        }

        void test()
        {
            foreach (Control item in panel1.Controls)
            {
                if (item.Name == "Enemy")
                {
                    foreach (Control wall in panel1.Controls)
                    {
                        if (item.Location.X + 35 != wall.Location.X && item.Location.Y != wall.Location.Y)
                        {
                            panel1.Controls.Remove(item);
                            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                            string path_enemy = projectDirectory + "//Resource//pontansp6.gif";
                            PictureBox picture = new PictureBox
                            {
                                Name = "Enemy",
                                Size = new Size(35, 35),
                                Location = new Point(item.Location.X + 7, item.Location.Y),
                                Tag = item.Tag
                            };
                            picture.ImageLocation = path_enemy;
                            picture.SizeMode = PictureBoxSizeMode.StretchImage;
                            panel1.Controls.Add(picture);
                        }
                        else
                        {
                            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                            string path_enemy = projectDirectory + "//Resource//pontansp6.gif";
                            PictureBox picture = new PictureBox
                            {
                                Name = "Enemy",
                                Size = new Size(35, 35),
                                Location = new Point(item.Location.X - 7, item.Location.Y),
                                Tag = item.Tag
                            };
                            picture.ImageLocation = path_enemy;
                            picture.SizeMode = PictureBoxSizeMode.StretchImage;
                            panel1.Controls.Add(picture);
                            panel1.Controls.Remove(item);
                        }
                    }
                }
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            balik.Dispose();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //g = e.Graphics;

            //foreach (var item in hardWall)
            //{
            //    Image IMG = Image.FromFile(item.Image);
            //    g.DrawImage(IMG, item.X * 35, item.Y * 35, item.W, item.H);
            //}

            //foreach (var item in softWall)
            //{
            //    Image IMG = Image.FromFile(item.Image);
            //    g.DrawImage(IMG, item.X * 35, item.Y * 35, item.W, item.H);
            //}

            // GAMBAR PLAYER
            //try
            //{
            //    Image imgPlayer = Image.FromFile(pl.Image);
            //    g.DrawImage(imgPlayer, pl.X * 35, pl.Y * 35, pl.W, pl.H);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message.ToString());
            //}
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            GenerateHardwall();
            GenerateEnemy();
            GeneratePlayer();
            Generatesofwall();
        }

        int idxJalanAtas = 0;
        int idxJalanBawah = 0;
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            int tempX, tempY;
            if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left) // GERAK KIRI
            {
                //tempX = pl.X - 1;
                //if (!cekTabrakTembok(tempX, pl.Y))
                //{
                //    pl.X--;
                //}
                //projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                //pl.Image = projectDirectory + "//Resource//Player//jalanKiri.png";

                tempX = xPlayer - 1;
                if (!cekTabrakTembok(tempX, yPlayer))
                {
                    xPlayer--;
                }

                projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                path_player = projectDirectory + "//Resource//Player//jalanKiri.png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);

            }

            if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right) // GERAK KANAN
            {
                //tempX = pl.X + 1;
                //if (!cekTabrakTembok(tempX, pl.Y))
                //{
                //    pl.X++;
                //}
                //projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                //pl.Image = projectDirectory + "//Resource//Player//jalanKanan.png";

                tempX = xPlayer + 1;
                if (!cekTabrakTembok(tempX, yPlayer))
                {
                    xPlayer++;
                }
                projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                path_player = projectDirectory + "//Resource//Player//jalanKanan.png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }

            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up) // GERAK ATAS
            {
                //tempY = pl.Y - 1;
                //if (!cekTabrakTembok(pl.X, tempY))
                //{
                //    pl.Y--;
                //    idxJalan = (idxJalan + 1) % 3;
                //}
                //projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                //pl.Image = projectDirectory + "//Resource//Player//belakang" + idxJalan + ".png";

                tempY = yPlayer - 1;
                idxJalanBawah = 0;
                if (!cekTabrakTembok(xPlayer, tempY))
                {
                    yPlayer--;
                }
                idxJalanAtas = (idxJalanAtas + 1) % 2;
                projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                path_player = projectDirectory + "//Resource//Player//belakang" + idxJalanAtas + ".png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }

            if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down) // GERAK BAWAH
            {
                //tempY = pl.Y + 1;
                //if (!cekTabrakTembok(pl.X, tempY))
                //{
                //    pl.Y++;
                //    idxJalan = (idxJalan + 1) % 3;
                //}
                //projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                //pl.Image = projectDirectory + "//Resource//Player//jalanDepan" + idxJalan + ".png";

                tempY = yPlayer + 1;
                idxJalanAtas = 0;
                if (!cekTabrakTembok(xPlayer, tempY))
                {
                    yPlayer++;
                }
                idxJalanBawah = (idxJalanBawah + 1) % 2;
                projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                path_player = projectDirectory + "//Resource//Player//jalanDepan" + idxJalanBawah + ".png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }

            if (e.KeyCode == Keys.Space)
            {
                if (bom == 0)
                {
                    projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
                    string path_bom = projectDirectory + "//Resource//bomber-man.gif";
                    PictureBox picture = new PictureBox
                    {
                        Name = "Bom",
                        Size = new Size(35, 35),
                        Location = new Point(xPlayer * 35, yPlayer * 35)
                    };
                    picture.ImageLocation = path_bom;
                    picture.SizeMode = PictureBoxSizeMode.StretchImage;
                    panel1.Controls.Add(picture);
                    bom++;
                }
            }

            //panel1.Invalidate();
        }

        void meledak()
        {
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            string path_ledakan = projectDirectory + "//Resource//panah.png";
            //ledakan tengah
            PictureBox picture = new PictureBox
            {
                Name = "ledakan",
                Size = new Size(35, 35),
                Location = new Point(bomX, bomY)
            };
            picture.ImageLocation = path_ledakan;
            picture.SizeMode = PictureBoxSizeMode.StretchImage;
            panel1.Controls.Add(picture);
            //ledakan sisi kiri
            for (int i = 1; i < 4; i++)
            {
                if (check_radius(bomX - (i * 35), bomY))
                {
                    PictureBox atas = new PictureBox
                    {
                        Name = "ledakan",
                        Size = new Size(35, 35),
                        Location = new Point(bomX - (i * 35), bomY)
                    };
                    atas.ImageLocation = path_ledakan;
                    atas.SizeMode = PictureBoxSizeMode.StretchImage;
                    panel1.Controls.Add(atas);
                }
                else
                {
                    i = 4;
                }
            }
            //ledakan sisi kanan
            for (int i = 1; i < 4; i++)
            {
                if (check_radius(bomX + (i * 35), bomY))
                {
                    PictureBox bawah = new PictureBox
                    {
                        Name = "ledakan",
                        Size = new Size(35, 35),
                        Location = new Point(bomX + (i * 35), bomY)
                    };
                    bawah.ImageLocation = path_ledakan;
                    bawah.SizeMode = PictureBoxSizeMode.StretchImage;
                    panel1.Controls.Add(bawah);
                }
                else
                {
                    i = 4;
                }
            }
            //ledakan sisi atas
            for (int i = 1; i < 4; i++)
            {
                if (check_radius(bomX, bomY - (i * 35)))
                {
                    PictureBox kiri = new PictureBox
                    {
                        Name = "ledakan",
                        Size = new Size(35, 35),
                        Location = new Point(bomX, bomY - (i * 35))
                    };
                    kiri.ImageLocation = path_ledakan;
                    kiri.SizeMode = PictureBoxSizeMode.StretchImage;
                    panel1.Controls.Add(kiri);
                }
                else
                {
                    i = 4;
                }
            }
            //ledakan sisi bawah
            for (int i = 1; i < 4; i++)
            {
                if (check_radius(bomX, bomY + (i * 35)))
                {
                    PictureBox kanan = new PictureBox
                    {
                        Name = "ledakan",
                        Size = new Size(35, 35),
                        Location = new Point(bomX, bomY + (i * 35))
                    };
                    kanan.ImageLocation = path_ledakan;
                    kanan.SizeMode = PictureBoxSizeMode.StretchImage;
                    panel1.Controls.Add(kanan);
                }
                else
                {
                    i = 4;
                }
            }
            ledakan++;
        }

        bool check_radius(int x, int y)
        {
            foreach (Control item in panel1.Controls)
            {
                if (item.Name == "Player")
                {
                    return true;
                }
                else
                {
                    if (item.Location.X == x && item.Location.Y == y)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        bool check_sisa_ledakan()
        {
            foreach (Control item in panel1.Controls)
            {
                if (item.Name == "ledakan")
                {
                    return true;
                }
            }

            return false;
        }

        bool cekTabrakTembok(int nextX, int nextY)
        {
            //bool cek = false;
            //Rectangle rec1, rec2;

            //foreach (var w in softWall)
            //{
            //    rec1 = new Rectangle(w.X, w.Y, w.W, w.H);
            //    rec2 = new Rectangle(nextX, nextY, pl.W, pl.H);
            //    if (rec1.IntersectsWith(rec2))
            //    {
            //        cek = true;
            //    }
            //}
            //foreach (var w in hardWall)
            //{
            //    rec1 = new Rectangle(w.X, w.Y, w.W, w.H);
            //    rec2 = new Rectangle(nextX, nextY, pl.W, pl.H);
            //    if (rec1.IntersectsWith(rec2))
            //    {
            //        cek = true;
            //    }
            //}

            //foreach (var w in softWall)
            //{
            //    if (w.X == nextX && w.Y == nextY)
            //    {
            //        cek = true;
            //    }
            //}
            //foreach (var w in hardWall)
            //{
            //    if (w.X == nextX && w.Y == nextY)
            //    {
            //        cek = true;
            //    }
            //}

            //return cek;

            foreach (Control item in panel1.Controls)
            {
                if (item.Location.X == nextX * 35 && item.Location.Y == nextY * 35)
                {
                    return true;
                }
            }
            return false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //test();
            if (bom == 1)
            {
                detik_bom++;
                if (detik_bom == 4)
                {
                    foreach (Control item in panel1.Controls)
                    {
                        if (item.Name == "Bom")
                        {
                            bomX = item.Location.X;
                            bomY = item.Location.Y;
                            panel1.Controls.Remove(item);
                        }
                    }
                    meledak();
                    bomX = -1;
                    bomY = -1;
                    detik_bom = 0;
                    bom--;
                }
            }
            if (ledakan == 1)
            {
                detik_ledakan++;
                if (detik_ledakan == 3)
                {
                    while (check_sisa_ledakan())
                    {
                        foreach (Control item in panel1.Controls)
                        {
                            if (item.Name == "ledakan")
                            {
                                panel1.Controls.Remove(item);
                            }
                        }
                    }
                    ledakan--;
                    detik_ledakan = 0;
                }
            }
        }

        private void Form2_KeyUp(object sender, KeyEventArgs e)
        {
            idxJalanAtas = 0;
            idxJalanBawah = 0;
            projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up)
            {
                path_player = projectDirectory + "//Resource//Player//belakangIdle.png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }

            if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down)
            {
                path_player = projectDirectory + "//Resource//Player//jalanDepanIdle.png";
                foreach (Control item in panel1.Controls)
                {
                    if (item.Name == "Player")
                    {
                        panel1.Controls.Remove(item);
                    }
                }
                PictureBox picture = new PictureBox
                {
                    Name = "Player",
                    Size = new Size(35, 35),
                    Location = new Point(xPlayer * 35, yPlayer * 35)
                };
                picture.ImageLocation = path_player;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                panel1.Controls.Add(picture);
            }
        }
    }
}
