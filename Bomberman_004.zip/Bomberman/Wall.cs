﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bomberman
{
    class Wall : Stats
    {
        int id;
        public Wall(int x, int y, int w, int h, string image, int id) : base(x, y, w, h, image)
        {
            this.id = id;
        }

        public int Id { get => id; set => id = value; }
    }
}
